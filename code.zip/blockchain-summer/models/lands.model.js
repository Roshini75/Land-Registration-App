const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const landSchema = new Schema({
    Name :{
     type: String,
     required: true,
     trim : true,
     minlength : 3,
     required: [true, 'Land name is  required'],
    },
    country :{
        type: String,
        required: true,
        trim : true,
        minlength : 3,
        required: [true, 'country is  required'],
       },
    city :{
        type: String,
        required: true,
        trim : true,
        minlength : 3,
        required: [true, 'city is  required'],
       },
   Area : {
    type: Number,
    required: true,
    trim : true,
    required: [true, 'Area is required']

  } 
});

var error;
const Lands = mongoose.model('lands', landSchema);
var lands = new Lands();
 error = lands.validateSync();

module.exports = Lands;