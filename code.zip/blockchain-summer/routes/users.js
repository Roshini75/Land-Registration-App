const express = require('express');
const mongo = require('mongodb');
const userRouter = express.Router();
const passport = require('passport');
const passportConfig = require('../passport');
const JWT = require('jsonwebtoken');
const User = require('../models/user.model');
const Land = require('../models/lands.model');


const signToken = userID => {
   return JWT.sign({
       iss :  "roshiniTadi",
       sub : userID 
   }, "roshiniTadi", {expiresIn : "24h"});
}


userRouter.post('/register' , (req,res) =>{
   const { name, email, mobile, username, password,address } = req.body;
   const role = "user";
   const newUser = new User({name, email, mobile, username, password,address,role});
   newUser.save().then(()=>res.json({msg:"User registered successfully!"})).
   catch(err=>res.status(400).json({error:true, errMsg:err}));
});


userRouter.get('/', (req,res)=>{
      User.find()
      .then((users)=>res.json(users))
      .catch(err=>res.status(400).json('Error '+err));
});

userRouter.post('/login' , passport.authenticate('local' , {session: false}), (req,res)=>{
   if(req.isAuthenticated()){
       const {_id, username, role} = req.user;
       const token = signToken(_id);
       res.cookie('access_token', token, {sameSite : true});
       res.status(200).json({isAuthenticated : true, user :{username,role},access_token:token});
  }
});

userRouter.get('/logout' , passport.authenticate('jwt' , {session: false}), (req,res)=>{
   res.setHeader('Access-Control-Allow-Origin','http://localhost:3000');
   res.setHeader('Access-Control-Allow-Credentials',true);
   res.clearCookie('access_token');
   res.json({user : {username :"",role:""},success:true});
});




userRouter.get('/authenticate' , passport.authenticate('jwt' , {session: false}), (req,res)=>{ 
   User.findById({_id : req.user._id}).populate('lands').exec((err,document)=>{
      if(err){
         res.status(400).json('Error '+err);
      }
      else{
         console.log(req.user);
         res.status(200).json({username:document.username,role:document.role, authenticated:true });
         console.log(document);
      }
   });
});




userRouter.get('/landData' , passport.authenticate('jwt' , {session: false}), (req,res)=>{
   res.setHeader('Access-Control-Allow-Origin','http://localhost:3000');
   res.setHeader('Access-Control-Allow-Credentials',true); 
   Land.find().exec((err,document)=>{
      if(err){
         res.status(400).json('Error '+err);
      }
      else{
         console.log(document);
         res.status(200).json({land:document, authenticated:true });
         console.log(document);
      }
   });
});

userRouter.get('/getHashedTransaction' , passport.authenticate('jwt' , {session: false}), (req,res)=>{
   res.setHeader('Access-Control-Allow-Origin','http://localhost:3000');
   res.setHeader('Access-Control-Allow-Credentials',true); 
   User.findById({_id : req.user._id}).populate('lands').exec((err,document)=>{
    if(err){
       res.status(400).json('Error '+err);
    }
    else{
        var command = "komodo-cli -regtest -ac_name=VCOIN sendtoaddress RYRDLBmtc3R1et7v74x3kVyZXnwgDHUJus" +" 10";
        const { exec } = require("child_process");
        exec(command, {
        cwd: 'C:\\Users\\tadir\\Desktop\\kmd'
          },(error, data, getter) => {
          if(error){
            console.log("error",error.message);
            return;
           }
          if(getter){
            return;
          }
    Land.find().exec((err,document)=>{
      if(err){
         res.status(400).json('Error '+err);
      }
      else{
         console.log(req.user);
         res.status(200).json({career:document, authenticated:true });
      } 
    });
          res.status(200).json({username:document.username,transid:data, authenticated:true });
          console.log(document);
      });
       
    }
 });
});


module.exports = userRouter;