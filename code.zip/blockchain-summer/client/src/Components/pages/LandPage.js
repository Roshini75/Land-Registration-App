import React from 'react';
import { Redirect } from "react-router-dom";
import {Container,Row,Col,Card,Button} from 'react-bootstrap';
import  {useContext,useState,useEffect} from 'react';
import { AuthContext } from '../content/AuthContext';
import AuthService from '../services/AuthService';
const  ProfilePage = props => {
const [openRegistermodal, setOpenRegistermodal] = useState(false);
const [tid, setTid] = useState(null);
const [lands, setLands] = useState([]);
const [redirect, setRedirect] = useState(null);
const [openModal, setOpenModal] = useState(false);
const [id, setId] = useState(null);
const [roleDesc, setRoleDesc] =  useState('');
const [name, setName] = useState('');
const [age, setAge] = useState('');
const [location, setLocation] = useState('');
const {user, setUser, isAuthenticated, setIsAuthenticated} = useContext(AuthContext);
useEffect(()=>{
   AuthService.GetLandData().then((data)=>{
       const {authenticated, land} = data;
       if((isAuthenticated && authenticated) || (document.cookie)){
          if(land){
              setLands(land);
          }
       }
    });
},[]);

const handleRoleDesc = (e) =>{
   setRoleDesc(e.target.value);
}

const handleName = (e) =>{
   setName(e.target.value);
}

const handleAge = (e) =>{
   setAge(e.target.value);
}

const handleLocation = (e) =>{
   setLocation(e.target.value);
}

const handleEdit=()=>{
   setOpenModal(true);
}

const handleCloseButton=()=>{
   setOpenModal(false);
   setOpenRegistermodal(false);
}

const handleProfileFormSubmit=(e)=>{
   e.preventDefault();
   e.stopPropagation();
   const profile={
      roleDesc : roleDesc,
      name : name,
      age :age,
      location : location,
      _id : id
   }
   AuthService.profileUpdate(profile).then((profileData)=>{
      const {authenticated} = profileData;
      if((authenticated && isAuthenticated) || (document.cookie && localStorage.getItem("role")==="admin")){
        alert("profile data updated successfully");
      }
   })
   
}

const handleRegisterButton = (data) =>{
   AuthService.GetTransactionId().then((d)=>{
      console.log("inside transaction");
      setTid(d.transid.replace(/[\n\r]/g, ''))
   });
   setOpenRegistermodal(true);
}



return(
    <Container fluid className="profile-container p-0 h-100">
     <div className = "profile-content">
        <div className="profile-heading">
        <h1>Available lands</h1>
       </div>
       <hr/>
       <Row className = "container-row">
       <Col md={12} sm={12}>
       </Col>
       </Row>
       <Row className = "container-row">
         {lands.map((data)=>{
          return(
           <Col className="profile-col justify-content-center" md={4} sm={12}>
           <Card style={{ width: '100%' }}>
           <Card.Body>
          <Card.Title>{data.Name}</Card.Title>
          <Card.Text>
            id : {data._id}
         </Card.Text>
         <Card.Text>
            country : {data.country}
         </Card.Text>
         <Card.Text>
            city : {data.city} 
         </Card.Text>
          <Card.Text>
            Area : {data.Area} sqmts
         </Card.Text>
            <Button onClick= {()=>handleRegisterButton(data)} variant="primary">Register</Button>
           </Card.Body>
          </Card>
           </Col>
         )})}
       </Row>
       </div>
       {openModal?(<div  className="popup">
          <div className="popup-inner">
             <span className="closebutton" onClick={handleCloseButton}>&times;</span>
             <form className="loginregform" onSubmit={handleProfileFormSubmit}>
              <div style={{textAlign: "center", color: "black"}}>
                 <h2 style={{color: "black"}}>Profile</h2>
               </div>
               <fieldset>
               <label for="role-description">Role description</label>
               <textarea value={roleDesc} onChange={handleRoleDesc} className="loginreginput" name="address" required={true} rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea><br/>
               <label for="name">Name:</label>
               <input type="text" value={name} onChange={handleName} className="loginreginput" name="username" required={true} pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/><br/>
               <label for="age">Age:</label>
                <input type="number" value={age} onChange={handleAge} className="loginreginput" name="age" required={true} pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/><br/>
                <label for="location">Location:</label>
               <textarea className="loginreginput"  value={location} onChange={handleLocation} name="location" required={true} rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea><br/>
              </fieldset>
                 <button type="submit" name="submit" className="loginregbutton" style={{marginTop: "30px"}}>Submit</button>
             </form>
         </div>
         </div>
        ):null}
        {openRegistermodal?(<div  className="popup">
          <div className="popup-inner">
             <span className="closebutton" onClick={handleCloseButton}>&times;</span>
             <form className="loginregform" onSubmit={handleProfileFormSubmit}>
              <div style={{textAlign: "center", color: "black"}}>
                 <h2 style={{color: "black"}}>transaction information</h2>
               </div>
              <p>The transaction information as follows</p>
              <label><b>{tid}</b></label>
             </form>
         </div>
         </div>
        ):null}
    </Container>
);
 
}
export default ProfilePage;