import React from 'react';
import {Container} from 'react-bootstrap';
class HomePage extends React.Component{
constructor(props){
    super(props);
    
}
 render(){
  return(
    <Container className="container-whole container-display p-0 m-0" fluid>
      <div class="main-heading">
        <h1>Land Registration</h1>
        <p className="main-subheading">with blockchain</p>
        <p>{this.props.res}</p>
    </div>
    </Container>
  )
 }
}
export default HomePage;