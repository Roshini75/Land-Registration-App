import React, { useEffect } from 'react';
import {Container,Row,Col,Card,Button} from 'react-bootstrap';
import  {useContext,useState} from 'react';
import { AuthContext } from '../content/AuthContext';
import AuthService from '../services/AuthService';

const ExperiencePage = props=>{
    const [tid, setTid] = useState(null);
    const [openRegistermodal, setOpenRegistermodal] = useState(false);
    const [openAddModal, setOpenAddModal] = useState(false);
    const [editFlag,setEditFlag] = useState(false);
    const [editId, setEditId] = useState(null);
    const [educationArray, setEducationArray] = useState(null);
    const [careerArray, setCareerArray] = useState(null);
    const [title, setTitle] = useState("");
    const [label1, setLabel1] = useState("");
    const [label2, setLabel2] = useState("");
    const [label3, setLabel3] = useState("");
    const [label4, setLabel4] = useState("");
    const [label1Value, setLabel1Value] = useState("");
    const [label2Value, setLabel2Value] = useState("");
    const [label3Value, setLabel3Value] = useState("");
    const [label4Value, setLabel4Value] = useState("");
    const {user, setUser, isAuthenticated, setIsAuthenticated} = useContext(AuthContext);
    const users = [
        {
          name : "James",

        },
        {
          name : "Chris",
        },
        {
            name : "Steve",
        },
        {
            name : "mathew",
        },
        {
            name : "Taylor",
        },
        {
            name : "jennifer",
        }
      ]

   
   const handleDelete = (type, obj) => {
       if(type==="education"){
           AuthService.deleteEducation(obj).then((data)=>{
               
           });
       }
       else if(type === "careers"){
        AuthService.deleteCareer(obj).then((data)=>{
               
        });
       }
   }
   const handleAdd = (classification) =>{
    var obj = null;
    if(classification === "education"){
        setTitle("Educations");
        setLabel1("University name");
        setLabel2("Time period");
        setLabel3("Course name");
        setLabel4("Course description");
         obj = {
             univName : label1Value,
             timePeriod : label2Value,
             courseName :label3Value,
             courseDesc : label4Value
         }

    }
    else if(classification === "careers"){
        setTitle("Careers");
        setLabel1("Service name");
        setLabel2("Time period");
        setLabel3("Role name");
        setLabel4("Role description");
        obj = {
            serviceName : label1Value,
            timePeriod : label2Value,
            roleName :label3Value,
            roleDesc : label4Value
        }
    }
    setOpenAddModal(true);
    
}

const handleEdit = (id) => {
    setOpenAddModal(true);
    setEditFlag(true);
    setEditId(id);
} 

const handleFormSubmit = (e) =>{
    e.preventDefault();
    e.stopPropagation();
    var obj = null;
    if(title === "Education"){
        obj ={
            univName : label1Value,
             timePeriod : label2Value,
             courseName :label3Value,
             courseDesc : label4Value
        }
        AuthService.addCareer(obj).then((data)=>{
            const {authenticated}= data;
            if((isAuthenticated && authenticated) || (document.cookie)){
                const arr = [...educationArray];
                arr.push(obj);
                setEducationArray(arr);
                alert("career data added");
            }
        });
    }
    else if(title === "Careers"){
        obj ={
            univName : label1Value,
             timePeriod : label2Value,
             courseName :label3Value,
             courseDesc : label4Value
        }
        AuthService.addCareer(obj).then((data)=>{
            const {authenticated}= data;
            if((isAuthenticated && authenticated) || (document.cookie)){
                    const arr = [...careerArray];
                    arr.push(obj);
                    setCareerArray(arr);
                    alert("career data added");
            }
       });
    }
    setOpenAddModal(false);
}

const handleEditFormSubmit = (e) =>{
    e.preventDefault();
    e.stopPropagation();
    setEditFlag(false);
    var obj = null;
    if(title === "Education"){
        obj ={
             _id      : editId,
             univName : label1Value,
             timePeriod : label2Value,
             courseName :label3Value,
             courseDesc : label4Value
        }
        AuthService.updateEducation(obj).then((data)=>{
            const {authenticated}= data;
            if((isAuthenticated && authenticated) || (document.cookie)){
                const arr = [...educationArray];
                for (var i in arr) {
                    if (arr[i]._id === editId) {
                        arr[i] = obj;
                       break; //Stop this loop, we found it!
                    }
                  }
                  setEducationArray(arr);
            }
        });
    }
    else if(title === "Careers"){
        obj ={
             _id      : editId,
             serviceName : label1Value,
             timePeriod : label2Value,
             roleName :label3Value,
             roleDesc : label4Value
        }
        AuthService.updateCareer(obj).then((data)=>{
            const {authenticated}= data;
            if((isAuthenticated && authenticated) || (document.cookie)){
                const arr = [...careerArray];
                for (var i in arr) {
                    if (arr[i]._id === editId) {
                        arr[i] = obj;
                       break; //Stop this loop, we found it!
                    }
                  }
                  setCareerArray(arr);
            }
         });
    }
    setOpenAddModal(false);
}


const handleCloseButton = ()=>{
    setOpenAddModal(false);
    setOpenRegistermodal(false);
}

const handleLabel1Value = (e) =>{
    setLabel1Value(e.target.value);
}

const handleLabel2Value = (e) =>{
    setLabel2Value(e.target.value);
}

const handleLabel3Value = (e) =>{
    setLabel3Value(e.target.value);
}

const handleLabel4Value = (e) =>{
    setLabel4Value(e.target.value);
}

const handleRegisterButton = (data) =>{
    AuthService.GetTransactionId().then((d)=>{
       console.log("inside transaction");
       setTid(d.transid.replace(/[\n\r]/g, ''))
    });
    setOpenRegistermodal(true);
 }
const handleForm = (e) => {
    if(editFlag){
       handleEditFormSubmit(e);
    }
    else{
        handleFormSubmit(e);
    }
}
 
  return(
    <Container fluid className="profile-container p-0 h-100">
     <div className = "profile-content">
       <div className="experience-heading">
       <h1>Available users</h1>
      </div>
      <hr/>
      <Row className = "container-row">
         {users.map((data)=>{
          return(
           <Col className="profile-col justify-content-center" md={4} sm={12}>
           <Card style={{ width: '100%' }}>
           <Card.Body>
          <Card.Title>{data.name}</Card.Title>
            <Button onClick = {handleRegisterButton} variant="primary">Transfer</Button>
           </Card.Body>
          </Card>
           </Col>
         )})}
       </Row>
       </div>
       {/* {openModal?(<div  className="popup">
          <div className="popup-inner">
             <span className="closebutton" onClick={handleCloseButton}>&times;</span>
             <form className="loginregform" onSubmit={handleProfileFormSubmit}>
              <div style={{textAlign: "center", color: "black"}}>
                 <h2 style={{color: "black"}}>Profile</h2>
               </div>
               <fieldset>
               <label for="role-description">Role description</label>
               <textarea value={roleDesc} onChange={handleRoleDesc} className="loginreginput" name="address" required={true} rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea><br/>
               <label for="name">Name:</label>
               <input type="text" value={name} onChange={handleName} className="loginreginput" name="username" required={true} pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/><br/>
               <label for="age">Age:</label>
                <input type="number" value={age} onChange={handleAge} className="loginreginput" name="age" required={true} pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/><br/>
                <label for="location">Location:</label>
               <textarea className="loginreginput"  value={location} onChange={handleLocation} name="location" required={true} rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea><br/>
              </fieldset>
                 <button type="submit" name="submit" className="loginregbutton" style={{marginTop: "30px"}}>Submit</button>
             </form>
         </div>
         </div>
        ):null} */}
        {openRegistermodal?(<div  className="popup">
          <div className="popup-inner">
             <span className="closebutton" onClick={handleCloseButton}>&times;</span>
             <form className="loginregform"> 
              <div style={{textAlign: "center", color: "black"}}>
                 <h2 style={{color: "black"}}>transaction information</h2>
               </div>
              <p>The transaction information as follows</p>
              <label><b>{tid}</b></label>
             </form>
         </div>
         </div>
        ):null}
   </Container>  
  );
  }
export default ExperiencePage;