export default {
    login : user =>{
        return fetch('users/login', {
         method : "post",
         body : JSON.stringify(user),
         headers :{
           'Content-Type' : 'application/json'
        }
  }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
    else{
   return { isAuthenticated : false, user : {username: "", role :""}};
    }
  });
},
register: user =>{
        return fetch('users/register', {
         method : "post",
         body : JSON.stringify(user),
         headers :{
           'Content-Type' : 'application/json',
        }
  }).then(res=>{
   if(res.status !== 401)
     return res.json().then(data => data);
   else
     return { isAuthenticated : false, user : {username: "", role :""}};
  });
},
logout : ()=>{
   return fetch('users/logout',{
      method :'GET',
      credentials : 'include',
   }).
   then(res=>{
      if(res.status !== 401)
         return res.json().then(data => data);
      else
         return { success:true,isAuthenticated : false, user : {username: "", role :""}};
     });
},
isAuthenticated : () => {
   return fetch('users/authenticate').then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });
},
GetProfileData : () =>{
   return fetch('users/profileData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 },
 
 profileUpdate: profile =>{
   return fetch('users/profileUpdate', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(profile)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });
 },

 GetEducationData : () =>{
   return fetch('users/educationData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 }, 
 GetLandData : () =>{
   return fetch('users/landData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 }, 
 GetTransactionId : () =>{
   return fetch('users/getHashedTransaction',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401){
             return res.json().then(data => {
                console.log(data)
                return data});
       }
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 },
 
 GetCareerData : () =>{
   return fetch('users/careerData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 }, 
 addCareer : career =>{
   return fetch('users/career', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(career)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 addEducation : education =>{
   return fetch('users/education', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(education)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

updateEducation : education =>{
   return fetch('users/educationUpdate', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(education)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 
 
 updateCareer : education =>{
   return fetch('users/careerUpdate', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(education)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 
 
 deleteEducation : id =>{
   return fetch('users/educationDelete', {
   method : 'delete',
   credentials : 'include',
   body : JSON.stringify(id)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 deleteCareer : id =>{
   return fetch('users/careerDelete', {
   method : 'delete',
   credentials : 'include',
   body : JSON.stringify(id)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 GetSkillData : () =>{
   return fetch('users/skillData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 }, 
 GetLanguageData : () =>{
   return fetch('users/languageData',{
      method :'GET',
      credentials : 'include',
   }).then(res => {
       if(res.status !== 401)
             return res.json().then(data => data);
       else
             return { isAuthenticated : false, user : {username: "", role :""}};
    });

 }, 

 addSkill : skill =>{
   return fetch('users/skill', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(skill)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 addLanguage : language =>{
   return fetch('users/language', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(language)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 updateSkill : skill =>{
   return fetch('users/skillUpdate', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(skill)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 
 
 updateLanguage : language =>{
   return fetch('users/languageUpdate', {
   headers :{
    'Content-Type' : 'application/json'
   },
   credentials : 'include',
   method : 'POST',
   body : JSON.stringify(language)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 deleteSkill : id =>{
   return fetch('users/skillDelete', {
   method : 'delete',
   credentials : 'include',
   body : JSON.stringify(id)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 

 deleteLanguage : id =>{
   return fetch('users/languageDelete', {
   method : 'delete',
   credentials : 'include',
   body : JSON.stringify(id)
    }).then(res=>{
   if(res.status !== 401)
   return res.json().then(data => data);
   else
   return { isAuthenticated : false, user : {username: "", role :""}};
  });

 }, 
 
}