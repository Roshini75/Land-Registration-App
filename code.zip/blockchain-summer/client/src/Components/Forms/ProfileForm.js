import React from 'react';
class ProfileForm extends React.Component{
    constructor(props){
        super(props);
        
    }
    render(){
        return(
          <div  class="popup">
          <div class="popup-inner">
             <span class="closebutton" onClick={this.handleCloseButton}>&times;</span>
             <form class="loginregform">
              <div style={{textAlign: "center", color: "black"}}>
                 <h2 style={{color: "black"}}>About Me</h2>
               </div>
               <fieldset>
               <label for="role-description">Role description</label>
               <textarea class="loginreginput" name="address" required={true} rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea><br/>
              </fieldset>
                 <button type="submit" name="submit" class="loginregbutton" style={{marginTop: "30px"}}>Submit</button>
             </form>
         </div>
         </div>
        )
    }

}
export default ProfileForm;