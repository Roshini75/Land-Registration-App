import React from 'react';
import {Glyphicon} from 'react-bootstrap';
import { FaRegStar, FaStar,FaEdit, FaTrash} from 'react-icons/fa';

class Star extends React.Component {

  constructor(props){
    super(props);
    //this.state = {star: this.props.star};             
  }

//   handleClick(starValue){    
//     this.setState({star:starValue});
    
//   } 

  render() { 
    var n = 0;
    let rows=[];
    while(n<this.props.rating){
      rows.push(<FaStar/>);
      n++;
   }
   while(n<5){
    rows.push(<FaRegStar/>);
    n++;
   }
   return (<div>{rows}</div>);
  }
}

export default Star;