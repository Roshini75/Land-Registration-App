import React from 'react';
import {Container,Row,Col} from 'react-bootstrap';
function Footer(){
    return(
        <footer>
        <Container fluid>
        <Row className="border-top justify-content-center p-1">
            <Col className="p-0">
              <p>Roshini Tadi</p>
            </Col> 
            <Col className="p-0 d-flex justify-content-end">
              <p>This site was made by Roshini Tadi.</p>
            </Col>
        </Row>
        </Container>
        </footer>
    );
}

export default Footer;