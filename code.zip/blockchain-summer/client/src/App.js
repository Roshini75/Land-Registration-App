import React, {useContext,useState} from 'react';
import { Redirect } from "react-router-dom";
import {withRouter} from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import { AuthContext } from './Components/content/AuthContext';
import AuthService from '../src/Components/services/AuthService';
import '../node_modules/font-awesome/css/font-awesome.min.css';
import {Container, Navbar,Nav} from 'react-bootstrap';
import HomePage from './Components/pages/HomePage';
import LandPage from './Components/pages/LandPage';
import UserPage from './Components/pages/UserPage';
import Footer from './Components/Footer';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from "react-router-dom";


const App = props => {
    const [redirect,setRedirect] = useState(null);
    const [message, setMessage] = useState('');
    const [authenticate, setAuthenticate] = useState(false);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [mobile, setMobile] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [repeatPassword, setRepeatPassword] = useState('');
    const [address, setAddress] = useState('');
    const [loginUser, setLoginUser] = useState('');
    const [loginPassword, setLoginPassword] = useState('');
    const authContext = useContext(AuthContext);
    const {user, setUser, isAuthenticated, setIsAuthenticated} = authContext;
    const [showRegisterModal, setShowRegisterModal] = useState(false);
    const [showLoginModal, setShowLoginModal] = useState(false);
    const [errors, setErrors] = useState(null);
  
  
  const handleCloseButtonForRegister=()=>{
     setShowRegisterModal(false);
    }

  const alertMessage = ()=>{
    alert("Please login in order to continue");
  }

  const onClickLogoutHandler=()=>{
    AuthService.logout().then(data=>{
      if(data.success){
        setUser(data.user);
        setIsAuthenticated(false);
        localStorage.setItem('role',"");
        setRedirect('/');
        console.log(redirect);
      }
      localStorage.setItem('role',"");
    });
  }
  
  const handleLoginSubmit=(e)=>{
    e.preventDefault();
    e.stopPropagation();
    console.log("log in");
    const user={
      username : loginUser,
      password : loginPassword
    }
    AuthService.login(user).then((data)=>{
      const {isAuthenticated,user,access_token} = data;
      if(isAuthenticated){
        setUser(user);
        setIsAuthenticated(isAuthenticated);
        const path = '/';
        const domain = 'localhost';
        const sameSite = 'Strict';
        document.cookie = 'access_token='+access_token+'; Path='+path+'; Domain='+domain+';  SameSite='+sameSite;
        console.log(document.cookie);
        localStorage.setItem('role',user.role);
        setRedirect('/');
      }
      else{
        alert("not authorized, please try again");
        localStorage.setItem('role',"");
        setRedirect('/');
      }
    });
    setShowLoginModal(false);
  }

  const handleRegisterSubmit = (e) =>{
    e.preventDefault();
    e.stopPropagation();
    console.log("log in");
    const user={
      name : name,
      email : email,
      username : username,
      mobile : mobile,
      password : password,
      address : address,
    }
    AuthService.register(user).then((data)=>{
      if(data.error){
        alert('Registration unsuccessful, Please try again');
        //history.push('http://localhost:3000/');
      }
      else{
        alert(data.msg);
        //history.push('http://localhost:3000/');
      }
    });
    setShowRegisterModal(false);

  }


  const handleCloseButtonForLogin=()=>{
    setShowLoginModal(false);
  }

  const handleLoginName = (e) =>{
    setLoginUser(e.target.value);
  }

  const handleLoginPassword = (e) =>{
    setLoginPassword(e.target.value);
  }

  const handleName = (e) =>{
    setName(e.target.value);
  }

  const handleEmail = (e) =>{
    setEmail(e.target.value);
  }

  const handleMobile = (e) =>{
    setMobile(e.target.value);
  }

  const handleUsername = (e) =>{
    setUsername(e.target.value);
  }

  const handlePassword = (e) =>{
    setPassword(e.target.value);
  }
  const handleRepeatPassword = (e) =>{
    setRepeatPassword(e.target.value);
  }

  const handleAddress = (e) =>{
    setAddress(e.target.value);
  }

  const handleLogin=()=>{
    setShowLoginModal(true);
  }

  const handleRegister=()=>{
    setShowRegisterModal(true);
  }

  return (
    <Router>  
    <Container className = "App p-0" fluid>
    <Navbar bg="transparent" expand="lg" className="border-bottom">
      <Navbar.Brand>Welcome to Land Registration Website</Navbar.Brand>
      <Navbar.Toggle className="border-0" aria-controls="navbar-toggle" />
      <Navbar.Collapse id="navbar-toggle">
      <Nav className="ml-auto">
      <Link className="nav-link" to="/">Home</Link>
      {document.cookie || isAuthenticated ?<Link className="nav-link" to="/lands">Available Lands</Link>:(<Link className="nav-link" to="/" onClick={alertMessage}>Available Lands</Link>)}
      {document.cookie || isAuthenticated?<Link className="nav-link" to="/users">Available users to transfer</Link>:(<Link className="nav-link" to="/" onClick={alertMessage}>Available users to transfer</Link>)}
      {!isAuthenticated && !document.cookie?(<Link className="nav-link"  onClick={handleLogin} to="/">Login</Link>):null}
      {!isAuthenticated && !document.cookie ?(<Link className="nav-link" onClick={handleRegister} to="/">Register</Link>):
      <Link className="nav-link" onClick={onClickLogoutHandler}>Logout</Link>}
      </Nav>
      </Navbar.Collapse>
    </Navbar>
    
    <Route path="/" exact render={()=> <HomePage />}/>
    <Route path="/lands" exact render={()=> <LandPage/>}/>
    <Route path="/users" exact render={()=> <UserPage/>}/>
    <Route path="/login" exact render={()=> <HomePage/>} />
    <Route path="/register" exact render={()=> <HomePage/>}/>
    <Footer/>
    {redirect?<Redirect to={redirect} />:null}
    {showLoginModal?(
            <div  class="popup">
             <div class="popup-inner">
                <span class="closebutton" onClick={handleCloseButtonForLogin}>&times;</span>
                <form class="loginregform" onSubmit={handleLoginSubmit}>
                 <div style={{textAlign: "center", color: "black"}}>
                    <h2 style={{color: "black"}}>Login</h2>
                  </div>
                  <fieldset>
                        <label for="name">Username:</label>
                        <input type="text" class="loginreginput" value={loginUser} onChange={handleLoginName} name="username" required="true" pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/>
                        <label for="quantity">Password:</label>
                        <input type="password" class="loginreginput" value={loginPassword} onChange={handleLoginPassword} name="password" required="true" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}" title="Must contain at least one number and one uppercase and lowercase letter, and with minimum of 8 and maximum of 10"/><br/>
                 </fieldset>
                    <button type="submit" name="submit" class="loginregbutton" style={{marginTop: "30px"}}>Submit</button>
                </form>
            </div>
        </div>):null}
    {showRegisterModal?(
    <div  class="popup">
    <div class="popup-inner">
        <span class="closebutton" onClick={handleCloseButtonForRegister}>&times;</span>
        <form class="loginregform" onSubmit={handleRegisterSubmit}>
            <div style={{textAlign:"center",color: "black"}}>
            <h2 style={{color: "black"}}>Register</h2>
            </div>
            <fieldset>
                <label for="name">Name Lastname:</label>
                <input type="text" class="loginreginput" value={name} onChange={handleName} name="name" required="true" pattern="[a-zA-Z][a-zA-Z\s]{2,}" title="Please enter more than two letters without including any numbers. Spaces are allowed only after a letter."/>
                <label for="email">Mail:</label>
                <input type="text"  class="loginreginput" value={email} onChange={handleEmail} name="email" required="true"/>
                <label for="mobile">Mobile Number:</label>
                <input type="text" class="loginreginput" value={mobile} onChange={handleMobile} name="mobile" required="true" pattern="[+][0-9]{11,12}" title="It must contain only a minimum of 11 digits and maximum of 12 digits and should start with a '+'" placeholder="+17738740927"/>
                <label for="name">Username:</label>
                <input type="text" class="loginreginput"  value={username} onChange={handleUsername} name="username" required="true" pattern="[A-Za-z-0-9]{3,14}" title="please use only numbers and alphabets with a minimum of 3 and maximum of 14"/>
                <label for="password">Password:</label>
                <input type="password"  class="loginreginput" value={password} onChange={handlePassword} name="password" required="true" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}" title="Must contain at least one number and one uppercase and lowercase letter, with a minimum of 8 and maximum of 10 characters"/>
                <label for="repeatpassword">Repeat Password:</label>
                <input type="password"  class="loginreginput" value={repeatPassword} onChange={handleRepeatPassword} name="repeatpassword" required="true" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}" title="Must contain at least one number and one uppercase and lowercase letter, with a minimum of 8 and maximum of 10 characters"/><br/>
                <label for="address">Address:</label>
                <textarea class="loginreginput" value={address} onChange={handleAddress} name="address" required="true" rows="4" pattern="[a-zA-Z0-9\s,.'-]{3,}" title="Characters may include a-z, A-Z alphabets, whitespace, comma(,), dot(.), apostrophe ('), and dash(-) symbols with minimum length 3"></textarea>
            </fieldset>
            <button class="loginregbutton" name="submit" type="submit" style={{marginTop: "30px"}}>Submit</button>
        </form>
    </div>
</div>):null}
    </Container>
    </Router>
  );
  }


export default App;
